THE RAINCHECK PIN / FREE STANDALONE QA SAMPLE v0.1.2-QA
This download is a pre-release playtest candidate, not a verified commercial release.
Select one folder: Screen, A4 or USLetter. Use the same edition for both players.
Open 01_START_HERE first. Investigator A reads 02, B reads 03.
Compare notes on 04_SHARED_WORKSHEET. Each hint is a separate PDF, numbered in sequence.
Open 99_ANSWER_KEY_OPEN_LAST only after making your verdict.
No external websites, host or QR codes needed.
PERSONAL PLAY: private household read/print allowed; redistribution and resale prohibited.
AI-ASSISTED CONTENT: story and layout made with generative AI assistance.

Please do not share answer-key text or spoiler screenshots publicly.

After the free verdict, read the LAST PAGE of 99_ANSWER_KEY_OPEN_LAST for an honest paid-case preview and current pre-launch status. No live purchase URL is available.
